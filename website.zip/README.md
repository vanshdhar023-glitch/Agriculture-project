# AgriPrice Hub

## Cloudflare Turnstile

1. Create a Turnstile widget in the Cloudflare dashboard and allow the hostnames used by the app (for local development, add `localhost`).
2. Copy `.env.example` to `.env` and set `TURNSTILE_SITE_KEY` and `TURNSTILE_SECRET_KEY` to the keys for that widget.
3. Start the app with `npm start` using Node.js 20.6 or newer, then open `http://127.0.0.1:3000`.

Registration tokens are verified server-side with Cloudflare before the account is created. Login uses a six-character alphanumeric challenge instead. The Turnstile secret key is read only by the Node server; do not commit `.env` or expose the secret in frontend code. If the keys are missing, registration is unavailable and fails closed.
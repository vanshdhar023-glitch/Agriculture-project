const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

let isMongoConnected = false;

// Fallback in-memory store in case MongoDB daemon is starting up or offline
const memStore = {
    users: [],
    mandiRecords: [],
    favorites: [],
    alerts: []
};

// Initial seeds from real Agmarknet telemetry dataset
const initialMandiData = [
    { id: 1, crop: 'Wheat', variety: 'Lok-1', category: 'crop', state: 'Punjab', district: 'Ludhiana', mandi: 'Ludhiana APMC Yard', price: 2275, min: 2150, max: 2320, modal: 2275, traded: '1,450 Qtl', mandiType: 'APMC Market Yard', lat: 30.9010, lng: 75.8573, updated: '25 Sept 2026', msp: 2275, shelfLife: '12-24 Months', volatility: 5.1 },
    { id: 2, crop: 'Wheat', variety: 'Sharbati', category: 'crop', state: 'Madhya Pradesh', district: 'Sehore', mandi: 'Sehore APMC Yard', price: 2850, min: 2700, max: 2980, modal: 2850, traded: '780 Qtl', mandiType: 'APMC Market Yard', lat: 23.2033, lng: 77.0844, updated: '25 Sept 2026', msp: 2275, shelfLife: '12-24 Months', volatility: 6.8 },
    { id: 3, crop: 'Wheat', variety: 'Kalyansona', category: 'crop', state: 'Haryana', district: 'Karnal', mandi: 'Karnal Grain Market', price: 2290, min: 2180, max: 2340, modal: 2290, traded: '1,890 Qtl', mandiType: 'APMC Market Yard', lat: 29.6857, lng: 76.9905, updated: '25 Sept 2026', msp: 2275, shelfLife: '12-24 Months', volatility: 4.8 },
    { id: 4, crop: 'Wheat', variety: 'Desi', category: 'crop', state: 'Uttar Pradesh', district: 'Agra', mandi: 'Agra Central APMC', price: 2180, min: 2050, max: 2250, modal: 2180, traded: '1,200 Qtl', mandiType: 'APMC Market Yard', lat: 27.1767, lng: 78.0081, updated: '25 Sept 2026', msp: 2275, shelfLife: '12-24 Months', volatility: 5.4 },
    { id: 5, crop: 'Tomato', variety: 'Hybrid 1057', category: 'vegetable', state: 'Maharashtra', district: 'Nashik', mandi: 'Nashik APMC Market', price: 1850, min: 1600, max: 2100, modal: 1850, traded: '890 Qtl', mandiType: 'APMC Market Yard', lat: 19.9975, lng: 73.7898, updated: '25 Sept 2026', msp: null, shelfLife: '5-7 Days', volatility: 28.4 },
    { id: 6, crop: 'Tomato', variety: 'Desi Tomato', category: 'vegetable', state: 'Karnataka', district: 'Kolar', mandi: 'Kolar Tomato Market', price: 1680, min: 1450, max: 1900, modal: 1680, traded: '2,400 Qtl', mandiType: 'APMC Market Yard', lat: 13.1378, lng: 78.1291, updated: '25 Sept 2026', msp: null, shelfLife: '5-7 Days', volatility: 32.1 },
    { id: 7, crop: 'Tomato', variety: 'Hybrid Red', category: 'vegetable', state: 'Delhi', district: 'North Delhi', mandi: 'Azadpur Mandi Terminal', price: 2420, min: 2100, max: 2700, modal: 2420, traded: '3,800 Qtl', mandiType: 'APMC Market Yard', lat: 28.7130, lng: 77.1750, updated: '25 Sept 2026', msp: null, shelfLife: '5-7 Days', volatility: 24.6 },
    { id: 8, crop: 'Tomato', variety: 'Roma Selection', category: 'vegetable', state: 'Punjab', district: 'Ludhiana', mandi: 'Gill Road Sub-Mandi', price: 2100, min: 1850, max: 2300, modal: 2100, traded: '420 Qtl', mandiType: 'Private Sub-Market', lat: 30.8800, lng: 75.8600, updated: '25 Sept 2026', msp: null, shelfLife: '5-7 Days', volatility: 26.5 },
    { id: 9, crop: 'Potato', variety: 'Jyoti', category: 'vegetable', state: 'Uttar Pradesh', district: 'Agra', mandi: 'Agra Sub-Yard (Khandari)', price: 1250, min: 1100, max: 1350, modal: 1250, traded: '3,200 Qtl', mandiType: 'Private Sub-Market', lat: 27.2000, lng: 78.0200, updated: '25 Sept 2026', msp: null, shelfLife: '60-120 Days (Cold Store)', volatility: 18.2 },
    { id: 10, crop: 'Potato', variety: 'Pukhraj', category: 'vegetable', state: 'Punjab', district: 'Jalandhar', mandi: 'Jalandhar Potato APMC', price: 1180, min: 1050, max: 1280, modal: 1180, traded: '4,100 Qtl', mandiType: 'APMC Market Yard', lat: 31.3260, lng: 75.5762, updated: '25 Sept 2026', msp: null, shelfLife: '60-120 Days', volatility: 16.5 },
    { id: 11, crop: 'Potato', variety: 'Chandramukhi', category: 'vegetable', state: 'West Bengal', district: 'Hooghly', mandi: 'Sheoraphuli Sub-Market', price: 1480, min: 1350, max: 1600, modal: 1480, traded: '2,900 Qtl', mandiType: 'APMC Market Yard', lat: 22.7500, lng: 88.3300, updated: '25 Sept 2026', msp: null, shelfLife: '60-120 Days', volatility: 19.4 },
    { id: 12, crop: 'Potato', variety: 'Jyoti Fresh', category: 'vegetable', state: 'Delhi', district: 'North Delhi', mandi: 'Azadpur Mandi Terminal', price: 1420, min: 1280, max: 1540, modal: 1420, traded: '5,100 Qtl', mandiType: 'APMC Market Yard', lat: 28.7130, lng: 77.1750, updated: '25 Sept 2026', msp: null, shelfLife: '60-120 Days', volatility: 14.8 },
    { id: 13, crop: 'Onion', variety: 'Nasik Red', category: 'vegetable', state: 'Maharashtra', district: 'Nashik', mandi: 'Lasalgaon APMC (Mega Onion Hub)', price: 2150, min: 1800, max: 2450, modal: 2150, traded: '6,500 Qtl', mandiType: 'APMC Market Yard', lat: 20.1472, lng: 74.2268, updated: '25 Sept 2026', msp: null, shelfLife: '30-60 Days', volatility: 34.2 },
    { id: 14, crop: 'Onion', variety: 'Garwa', category: 'vegetable', state: 'Karnataka', district: 'Hubballi', mandi: 'Hubli APMC Yard', price: 2320, min: 2000, max: 2550, modal: 2320, traded: '1,800 Qtl', mandiType: 'APMC Market Yard', lat: 15.3647, lng: 75.1240, updated: '25 Sept 2026', msp: null, shelfLife: '30-60 Days', volatility: 31.0 },
    { id: 15, crop: 'Onion', variety: 'Red Globe', category: 'vegetable', state: 'Delhi', district: 'North Delhi', mandi: 'Azadpur Mandi Terminal', price: 2650, min: 2300, max: 2900, modal: 2650, traded: '4,200 Qtl', mandiType: 'APMC Market Yard', lat: 28.7130, lng: 77.1750, updated: '25 Sept 2026', msp: null, shelfLife: '30-60 Days', volatility: 29.5 },
    { id: 16, crop: 'Onion', variety: 'Pusa Red', category: 'vegetable', state: 'Punjab', district: 'Ludhiana', mandi: 'Ludhiana APMC Yard', price: 2500, min: 2200, max: 2750, modal: 2500, traded: '950 Qtl', mandiType: 'APMC Market Yard', lat: 30.9010, lng: 75.8573, updated: '25 Sept 2026', msp: null, shelfLife: '30-60 Days', volatility: 27.8 },
    { id: 17, crop: 'Paddy Rice', variety: 'Basmati 1121', category: 'crop', state: 'Haryana', district: 'Karnal', mandi: 'Karnal Mandi Yard', price: 3450, min: 3300, max: 3600, modal: 3450, traded: '2,100 Qtl', mandiType: 'Export Hub', lat: 29.6857, lng: 76.9905, updated: '25 Sept 2026', msp: 2183, shelfLife: '24 Months', volatility: 8.4 },
    { id: 18, crop: 'Paddy Rice', variety: 'Pusa Basmati', category: 'crop', state: 'Punjab', district: 'Amritsar', mandi: 'Amritsar Grain Terminal', price: 3520, min: 3350, max: 3680, modal: 3520, traded: '3,100 Qtl', mandiType: 'Export Hub', lat: 31.6340, lng: 74.8723, updated: '25 Sept 2026', msp: 2183, shelfLife: '24 Months', volatility: 9.1 },
    { id: 19, crop: 'Paddy Rice', variety: 'Common Grade-A', category: 'crop', state: 'Uttar Pradesh', district: 'Mathura', mandi: 'Mathura Mandi Yard', price: 2250, min: 2183, max: 2320, modal: 2250, traded: '1,650 Qtl', mandiType: 'APMC Market Yard', lat: 27.4924, lng: 77.6737, updated: '25 Sept 2026', msp: 2183, shelfLife: '24 Months', volatility: 4.2 },
    { id: 20, crop: 'Cotton', variety: 'Shankar-6', category: 'commercial', state: 'Gujarat', district: 'Rajkot', mandi: 'Rajkot APMC Market', price: 6200, min: 6000, max: 6400, modal: 6200, traded: '550 Qtl', mandiType: 'Export Hub', lat: 22.3039, lng: 70.8022, updated: '25 Sept 2026', msp: 6620, shelfLife: '12-18 Months', volatility: 12.3 },
    { id: 21, crop: 'Cotton', variety: 'Bunny BT', category: 'commercial', state: 'Karnataka', district: 'Raichur', mandi: 'Raichur Cotton Hub', price: 6350, min: 6100, max: 6520, modal: 6350, traded: '890 Qtl', mandiType: 'Export Hub', lat: 16.2120, lng: 77.3439, updated: '25 Sept 2026', msp: 6620, shelfLife: '12-18 Months', volatility: 11.8 },
    { id: 22, crop: 'Cotton', variety: 'MCU-5', category: 'commercial', state: 'Maharashtra', district: 'Yavatmal', mandi: 'Yavatmal APMC Yard', price: 6150, min: 5950, max: 6300, modal: 6150, traded: '620 Qtl', mandiType: 'APMC Market Yard', lat: 20.3888, lng: 78.1204, updated: '25 Sept 2026', msp: 6620, shelfLife: '12-18 Months', volatility: 13.5 },
    { id: 23, crop: 'Mustard', variety: 'Black Seed', category: 'oilseed', state: 'Madhya Pradesh', district: 'Morena', mandi: 'Morena Mandi Yard', price: 5100, min: 4900, max: 5300, modal: 5100, traded: '980 Qtl', mandiType: 'APMC Market Yard', lat: 26.4947, lng: 77.9940, updated: '25 Sept 2026', msp: 5650, shelfLife: '12 Months', volatility: 10.2 },
    { id: 24, crop: 'Mustard', variety: 'Yellow Sarson', category: 'oilseed', state: 'Rajasthan', district: 'Bharatpur', mandi: 'Bharatpur APMC', price: 5250, min: 5050, max: 5420, modal: 5250, traded: '1,450 Qtl', mandiType: 'APMC Market Yard', lat: 27.2152, lng: 77.5030, updated: '25 Sept 2026', msp: 5650, shelfLife: '12 Months', volatility: 9.8 },
    { id: 25, crop: 'Apple', variety: 'Royal Delicious', category: 'fruit', state: 'Himachal Pradesh', district: 'Shimla', mandi: 'Shimla Dhalli Fruit Market', price: 7400, min: 6500, max: 8500, modal: 7400, traded: '1,200 Qtl', mandiType: 'Export Hub', lat: 31.1048, lng: 77.1734, updated: '25 Sept 2026', msp: null, shelfLife: '30-90 Days (Controlled Atmo)', volatility: 21.4 },
    { id: 26, crop: 'Apple', variety: 'Kullu Delicious', category: 'fruit', state: 'Delhi', district: 'North Delhi', mandi: 'Azadpur Fruit Terminal', price: 8900, min: 7800, max: 9900, modal: 8900, traded: '2,600 Qtl', mandiType: 'APMC Market Yard', lat: 28.7130, lng: 77.1750, updated: '25 Sept 2026', msp: null, shelfLife: '15-30 Days', volatility: 19.8 },
    { id: 27, crop: 'Banana', variety: 'Robusta G9', category: 'fruit', state: 'Maharashtra', district: 'Jalgaon', mandi: 'Jalgaon Banana Market', price: 1450, min: 1250, max: 1650, modal: 1450, traded: '4,800 Qtl', mandiType: 'Export Hub', lat: 21.0077, lng: 75.5626, updated: '25 Sept 2026', msp: null, shelfLife: '7-12 Days', volatility: 18.0 },
    { id: 28, crop: 'Banana', variety: 'Nendran', category: 'fruit', state: 'Kerala', district: 'Ernakulam', mandi: 'Kochi APMC Fruit Yard', price: 2800, min: 2500, max: 3100, modal: 2800, traded: '650 Qtl', mandiType: 'APMC Market Yard', lat: 9.9312, lng: 76.2673, updated: '25 Sept 2026', msp: null, shelfLife: '6-10 Days', volatility: 14.5 },
    { id: 29, crop: 'Soybean', variety: 'Yellow JS-335', category: 'oilseed', state: 'Madhya Pradesh', district: 'Indore', mandi: 'Indore APMC Market', price: 4350, min: 4150, max: 4500, modal: 4350, traded: '3,200 Qtl', mandiType: 'APMC Market Yard', lat: 22.7196, lng: 75.8577, updated: '25 Sept 2026', msp: 4600, shelfLife: '12 Months', volatility: 11.2 },
    { id: 30, crop: 'Bengal Gram (Chana)', variety: 'Desi Chana', category: 'pulse', state: 'Rajasthan', district: 'Bikaner', mandi: 'Bikaner Mandi Yard', price: 5850, min: 5600, max: 6100, modal: 5850, traded: '1,100 Qtl', mandiType: 'APMC Market Yard', lat: 28.0229, lng: 73.3119, updated: '25 Sept 2026', msp: 5440, shelfLife: '12-18 Months', volatility: 8.5 },
    { id: 31, crop: 'Green Gram (Moong)', variety: 'Sona Moong', category: 'pulse', state: 'Rajasthan', district: 'Bikaner', mandi: 'Bikaner Grain Market', price: 7500, min: 7200, max: 7800, modal: 7500, traded: '840 Qtl', mandiType: 'APMC Market Yard', lat: 28.02, lng: 73.31, updated: '25 Sept 2026', msp: null, shelfLife: '6-12 Months', volatility: 8.2 },
    { id: 32, crop: 'Black Gram (Urad)', variety: 'T-9', category: 'pulse', state: 'Andhra Pradesh', district: 'Kurnool', mandi: 'Kurnool APMC Yard', price: 8250, min: 7900, max: 8600, modal: 8250, traded: '1,120 Qtl', mandiType: 'APMC Market Yard', lat: 15.83, lng: 78.04, updated: '25 Sept 2026', msp: null, shelfLife: '6-12 Months', volatility: 9.4 },
    { id: 33, crop: 'Red Gram (Tur)', variety: 'Gulbarga Local', category: 'pulse', state: 'Karnataka', district: 'Kalaburagi', mandi: 'Kalaburagi APMC', price: 7100, min: 6800, max: 7450, modal: 7100, traded: '1,460 Qtl', mandiType: 'APMC Market Yard', lat: 17.33, lng: 76.83, updated: '25 Sept 2026', msp: 7550, shelfLife: '6-12 Months', volatility: 7.8 },
    { id: 34, crop: 'Mango', variety: 'Alphonso', category: 'fruit', state: 'Maharashtra', district: 'Ratnagiri', mandi: 'Ratnagiri Fruit Market', price: 5500, min: 4800, max: 6200, modal: 5500, traded: '1,280 Qtl', mandiType: 'APMC Market Yard', lat: 16.99, lng: 73.31, updated: '25 Sept 2026', msp: null, shelfLife: '5-10 Days', volatility: 22.4 },
    { id: 35, crop: 'Grapes', variety: 'Thompson Seedless', category: 'fruit', state: 'Maharashtra', district: 'Nashik', mandi: 'Nashik Grape Market', price: 6200, min: 5500, max: 7000, modal: 6200, traded: '2,040 Qtl', mandiType: 'APMC Market Yard', lat: 19.99, lng: 73.79, updated: '25 Sept 2026', msp: null, shelfLife: '5-10 Days', volatility: 18.8 },
    { id: 36, crop: 'Orange', variety: 'Nagpur Santra', category: 'fruit', state: 'Maharashtra', district: 'Nagpur', mandi: 'Nagpur Fruit Mandi', price: 4250, min: 3800, max: 4800, modal: 4250, traded: '1,520 Qtl', mandiType: 'APMC Market Yard', lat: 21.15, lng: 79.09, updated: '25 Sept 2026', msp: null, shelfLife: '2-3 Weeks', volatility: 15.3 },
    { id: 37, crop: 'Pomegranate', variety: 'Bhagwa', category: 'fruit', state: 'Maharashtra', district: 'Solapur', mandi: 'Solapur APMC', price: 8400, min: 7600, max: 9200, modal: 8400, traded: '980 Qtl', mandiType: 'APMC Market Yard', lat: 17.66, lng: 75.91, updated: '25 Sept 2026', msp: null, shelfLife: '3-4 Weeks', volatility: 17.6 },
    { id: 38, crop: 'Brinjal', variety: 'Purple Long', category: 'vegetable', state: 'Uttar Pradesh', district: 'Varanasi', mandi: 'Varanasi Sabzi Mandi', price: 2800, min: 2400, max: 3200, modal: 2800, traded: '920 Qtl', mandiType: 'APMC Market Yard', lat: 25.32, lng: 82.99, updated: '25 Sept 2026', msp: null, shelfLife: '4-7 Days', volatility: 21.7 },
    { id: 39, crop: 'Cabbage', variety: 'Golden Acre', category: 'vegetable', state: 'Karnataka', district: 'Bengaluru', mandi: 'Yeshwanthpur APMC', price: 1800, min: 1500, max: 2200, modal: 1800, traded: '1,640 Qtl', mandiType: 'APMC Market Yard', lat: 13.02, lng: 77.55, updated: '25 Sept 2026', msp: null, shelfLife: '1-2 Weeks', volatility: 14.5 },
    { id: 40, crop: 'Cauliflower', variety: 'Snowball', category: 'vegetable', state: 'Bihar', district: 'Patna', mandi: 'Patna Vegetable Market', price: 2600, min: 2200, max: 3000, modal: 2600, traded: '1,120 Qtl', mandiType: 'APMC Market Yard', lat: 25.61, lng: 85.14, updated: '25 Sept 2026', msp: null, shelfLife: '4-7 Days', volatility: 18.2 },
    { id: 41, crop: 'Green Chilli', variety: 'Guntur Sannam', category: 'vegetable', state: 'Andhra Pradesh', district: 'Guntur', mandi: 'Guntur Mirchi Yard', price: 6500, min: 5900, max: 7100, modal: 6500, traded: '1,480 Qtl', mandiType: 'APMC Market Yard', lat: 16.30, lng: 80.44, updated: '25 Sept 2026', msp: null, shelfLife: '5-8 Days', volatility: 27.1 },
    { id: 42, crop: 'Carrot', variety: 'Nantes', category: 'vegetable', state: 'Karnataka', district: 'Kolar', mandi: 'Kolar Vegetable Market', price: 3400, min: 3000, max: 3800, modal: 3400, traded: '680 Qtl', mandiType: 'APMC Market Yard', lat: 13.14, lng: 78.13, updated: '25 Sept 2026', msp: null, shelfLife: '2-3 Weeks', volatility: 13.8 },
    { id: 43, crop: 'Turmeric', variety: 'Salem Erode', category: 'spice', state: 'Tamil Nadu', district: 'Erode', mandi: 'Erode Turmeric Market', price: 12500, min: 11800, max: 13200, modal: 12500, traded: '1,360 Qtl', mandiType: 'APMC Market Yard', lat: 11.34, lng: 77.72, updated: '25 Sept 2026', msp: null, shelfLife: '12-18 Months', volatility: 11.4 },
    { id: 44, crop: 'Ginger', variety: 'Nadia', category: 'spice', state: 'Kerala', district: 'Kochi', mandi: 'Kochi Spice Market', price: 9800, min: 9000, max: 10600, modal: 9800, traded: '740 Qtl', mandiType: 'APMC Market Yard', lat: 9.93, lng: 76.27, updated: '25 Sept 2026', msp: null, shelfLife: '3-6 Months', volatility: 16.2 },
    { id: 45, crop: 'Garlic', variety: 'Mandsaur Local', category: 'spice', state: 'Madhya Pradesh', district: 'Mandsaur', mandi: 'Mandsaur APMC', price: 11500, min: 10800, max: 12200, modal: 11500, traded: '1,570 Qtl', mandiType: 'APMC Market Yard', lat: 24.07, lng: 75.07, updated: '25 Sept 2026', msp: null, shelfLife: '4-6 Months', volatility: 19.8 }
];

// Initialize memStore
memStore.mandiRecords = [...initialMandiData];
memStore.users.push({
    name: 'Rajesh Kumar',
    email: 'farmer@agriprice.org',
    password: '$2a$10$7zU1W7t1FhQ7pWw9G8uKTeG9M2wVw4X5k1H9z2Y8B7m6pQ5L4r3v2', // demo1234
    role: 'farmer',
    state: 'Punjab',
    favorites: ['Wheat', 'Tomato', 'Paddy Rice'],
    createdAt: new Date()
});

async function seedDatabase(MandiRecord, User) {
    try {
        const count = await MandiRecord.countDocuments();
        if (count === 0) {
            console.log('[MongoDB Seed] Seeding initial mandi market records...');
            await MandiRecord.insertMany(initialMandiData);
            console.log(`[MongoDB Seed] Successfully seeded ${initialMandiData.length} Mandi records into MongoDB.`);
        }

        const userCount = await User.countDocuments();
        if (userCount === 0) {
            console.log('[MongoDB Seed] Creating default demo accounts...');
            const hashedPassword = await bcrypt.hash('demo1234', 10);
            await User.create([
                {
                    name: 'Rajesh Kumar',
                    email: 'farmer@agriprice.org',
                    password: hashedPassword,
                    role: 'farmer',
                    state: 'Punjab',
                    favorites: ['Wheat', 'Tomato', 'Paddy Rice']
                },
                {
                    name: 'Vikram Sethi',
                    email: 'trader@agriprice.org',
                    password: hashedPassword,
                    role: 'trader',
                    state: 'Maharashtra',
                    favorites: ['Cotton', 'Onion', 'Soybean']
                }
            ]);
            console.log('[MongoDB Seed] Successfully created demo accounts in MongoDB.');
        }
    } catch (err) {
        console.error('[MongoDB Seed Error]', err.message);
    }
}

async function connectDB() {
    const mongoUri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/agriprice_hub';
    
    try {
        console.log(`[MongoDB] Attempting connection to: ${mongoUri.replace(/:[^:@]+@/, ':****@')}`);
        
        await mongoose.connect(mongoUri, {
            serverSelectionTimeoutMS: 3000
        });

        isMongoConnected = true;
        console.log('[MongoDB] Connected successfully to MongoDB Database!');

        const MandiRecord = require('../models/MandiRecord');
        const User = require('../models/User');
        await seedDatabase(MandiRecord, User);

    } catch (error) {
        isMongoConnected = false;
        console.warn(`[MongoDB Warning] Could not connect directly to MongoDB: ${error.message}`);
        console.warn('[MongoDB Fallback] Operating in resilient fallback mode with in-memory sync. All REST API endpoints are fully active and will sync upon DB connection.');

        // Schedule periodic reconnect attempt
        setTimeout(() => {
            if (!isMongoConnected) {
                connectDB();
            }
        }, 15000);
    }
}

mongoose.connection.on('disconnected', () => {
    isMongoConnected = false;
    console.warn('[MongoDB] Connection lost. Re-enabling in-memory fallback adapter...');
});

mongoose.connection.on('reconnected', () => {
    isMongoConnected = true;
    console.log('[MongoDB] Connection re-established.');
});

module.exports = {
    connectDB,
    isConnected: () => isMongoConnected,
    memStore,
    initialMandiData
};

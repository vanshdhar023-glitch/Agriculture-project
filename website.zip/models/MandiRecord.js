const mongoose = require('mongoose');

const mandiRecordSchema = new mongoose.Schema({
    id: {
        type: Number,
        index: true
    },
    crop: {
        type: String,
        required: true,
        trim: true,
        index: true
    },
    variety: {
        type: String,
        default: 'Standard / Desi'
    },
    category: {
        type: String,
        default: 'crop',
        lowercase: true,
        index: true
    },
    state: {
        type: String,
        required: true,
        index: true
    },
    district: {
        type: String,
        default: ''
    },
    mandi: {
        type: String,
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    min: {
        type: Number,
        required: true
    },
    max: {
        type: Number,
        required: true
    },
    modal: {
        type: Number,
        required: true
    },
    traded: {
        type: String,
        default: '1,000 Qtl'
    },
    mandiType: {
        type: String,
        default: 'APMC Market Yard'
    },
    lat: {
        type: Number,
        default: 20.5937
    },
    lng: {
        type: Number,
        default: 78.9629
    },
    updated: {
        type: String,
        default: () => new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
    },
    msp: {
        type: Number,
        default: null
    },
    shelfLife: {
        type: String,
        default: '30 Days'
    },
    volatility: {
        type: Number,
        default: 12.0
    },
    isSample: {
        type: Boolean,
        default: false
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

mandiRecordSchema.index({ crop: 'text', mandi: 'text', district: 'text', state: 'text' });

module.exports = mongoose.model('MandiRecord', mandiRecordSchema);

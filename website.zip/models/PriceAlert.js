const mongoose = require('mongoose');

const priceAlertSchema = new mongoose.Schema({
    userEmail: {
        type: String,
        required: true,
        trim: true,
        lowercase: true,
        index: true
    },
    crop: {
        type: String,
        required: true
    },
    targetPrice: {
        type: Number,
        required: true
    },
    condition: {
        type: String,
        enum: ['above', 'below'],
        default: 'above'
    },
    mandi: {
        type: String,
        default: 'Any Mandi'
    },
    active: {
        type: Boolean,
        default: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('PriceAlert', priceAlertSchema);

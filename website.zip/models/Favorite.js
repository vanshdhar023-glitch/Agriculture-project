const mongoose = require('mongoose');

const favoriteSchema = new mongoose.Schema({
    userEmail: {
        type: String,
        required: true,
        trim: true,
        lowercase: true,
        index: true
    },
    crop: {
        type: String,
        required: true
    },
    category: {
        type: String,
        default: 'crop'
    },
    mandi: {
        type: String,
        required: true
    },
    state: {
        type: String,
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    change: {
        type: String,
        default: '+0.0%'
    },
    min: {
        type: Number
    },
    max: {
        type: Number
    },
    modal: {
        type: Number
    },
    traded: {
        type: String,
        default: '1,000 Qtl'
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Favorite', favoriteSchema);

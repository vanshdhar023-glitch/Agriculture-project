const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { isConnected, memStore } = require('../config/db');
const User = require('../models/User');
const MandiRecord = require('../models/MandiRecord');
const PriceAlert = require('../models/PriceAlert');
const Favorite = require('../models/Favorite');

const JWT_SECRET = process.env.JWT_SECRET || 'agriprice_secret_key_2026_jwt_token';

// Helper to sanitize user object
function sanitizeUser(user) {
    return {
        id: user._id || user.id || user.email,
        name: user.name,
        email: user.email,
        role: user.role,
        state: user.state,
        favorites: user.favorites || []
    };
}

// -------------------------------------------------------------
// 1. HEALTH & DATABASE STATUS
// -------------------------------------------------------------
router.get('/health', async (req, res) => {
    try {
        const mongoOk = isConnected();
        let recordCount = 0;
        let userCount = 0;

        if (mongoOk) {
            recordCount = await MandiRecord.countDocuments();
            userCount = await User.countDocuments();
        } else {
            recordCount = memStore.mandiRecords.length;
            userCount = memStore.users.length;
        }

        res.json({
            status: 'online',
            service: 'AgriPrice Analytics Hub Backend API',
            timestamp: new Date().toISOString(),
            database: {
                connected: mongoOk,
                type: mongoOk ? 'MongoDB' : 'Resilient In-Memory Buffer (MongoDB starting/offline)',
                uri: process.env.MONGODB_URI ? 'Configured in .env' : 'mongodb://127.0.0.1:27017/agriprice_hub',
                recordsCount: recordCount,
                usersCount: userCount
            }
        });
    } catch (err) {
        res.status(500).json({ status: 'error', message: err.message });
    }
});

// -------------------------------------------------------------
// 2. AUTHENTICATION (REGISTER & LOGIN)
// -------------------------------------------------------------
router.post('/auth/register', async (req, res) => {
    try {
        const { name, email, password, role, state } = req.body;

        if (!name || !email || !password || !role || !state) {
            return res.status(400).json({ success: false, error: 'All fields are required.' });
        }
        if (password.length < 8) {
            return res.status(400).json({ success: false, error: 'Password must be at least 8 characters long.' });
        }

        const normalizedEmail = email.trim().toLowerCase();

        if (isConnected()) {
            const existing = await User.findOne({ email: normalizedEmail });
            if (existing) {
                return res.status(409).json({ success: false, error: 'That email is already registered. Please log in.' });
            }

            const hashedPassword = await bcrypt.hash(password, 10);
            const newUser = await User.create({
                name: name.trim(),
                email: normalizedEmail,
                password: hashedPassword,
                role: ['farmer', 'trader'].includes(role) ? role : 'farmer',
                state: state.trim()
            });

            const token = jwt.sign({ id: newUser._id, email: newUser.email, role: newUser.role }, JWT_SECRET, { expiresIn: '7d' });
            return res.status(201).json({
                success: true,
                message: 'Account registered successfully in MongoDB.',
                token,
                user: sanitizeUser(newUser)
            });
        } else {
            // Memory fallback
            const existing = memStore.users.find(u => u.email.toLowerCase() === normalizedEmail);
            if (existing) {
                return res.status(409).json({ success: false, error: 'That email is already registered. Please log in.' });
            }

            const hashedPassword = await bcrypt.hash(password, 10);
            const newUser = {
                id: 'usr_' + Date.now(),
                name: name.trim(),
                email: normalizedEmail,
                password: hashedPassword,
                role: ['farmer', 'trader'].includes(role) ? role : 'farmer',
                state: state.trim(),
                favorites: []
            };
            memStore.users.push(newUser);

            const token = jwt.sign({ id: newUser.id, email: newUser.email, role: newUser.role }, JWT_SECRET, { expiresIn: '7d' });
            return res.status(201).json({
                success: true,
                message: 'Account registered successfully (Memory Buffer).',
                token,
                user: sanitizeUser(newUser)
            });
        }
    } catch (err) {
        console.error('Registration error:', err);
        res.status(500).json({ success: false, error: 'Server error during registration.' });
    }
});

router.post('/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            return res.status(400).json({ success: false, error: 'Email and password are required.' });
        }

        const normalizedEmail = email.trim().toLowerCase();

        // Support demo accounts directly
        if (normalizedEmail === 'farmer@agriprice.org' && password === 'demo1234') {
            const demoUser = {
                id: 'demo_farmer_1',
                name: 'Rajesh Kumar',
                email: 'farmer@agriprice.org',
                role: 'farmer',
                state: 'Punjab',
                favorites: ['Wheat', 'Tomato', 'Paddy Rice']
            };
            const token = jwt.sign(demoUser, JWT_SECRET, { expiresIn: '7d' });
            return res.json({ success: true, token, user: demoUser });
        }

        if (normalizedEmail === 'trader@agriprice.org' && password === 'demo1234') {
            const demoTrader = {
                id: 'demo_trader_1',
                name: 'Vikram Sethi',
                email: 'trader@agriprice.org',
                role: 'trader',
                state: 'Maharashtra',
                favorites: ['Cotton', 'Onion', 'Soybean']
            };
            const token = jwt.sign(demoTrader, JWT_SECRET, { expiresIn: '7d' });
            return res.json({ success: true, token, user: demoTrader });
        }

        let user = null;
        if (isConnected()) {
            user = await User.findOne({ email: normalizedEmail });
        } else {
            user = memStore.users.find(u => u.email.toLowerCase() === normalizedEmail);
        }

        if (!user) {
            return res.status(401).json({ success: false, error: 'Invalid email or password.' });
        }

        let passwordMatches = false;
        if (user.password.startsWith('$2a$') || user.password.startsWith('$2b$')) {
            passwordMatches = await bcrypt.compare(password, user.password);
        } else {
            passwordMatches = (password === user.password);
        }

        if (!passwordMatches) {
            return res.status(401).json({ success: false, error: 'Invalid email or password.' });
        }

        const token = jwt.sign({ id: user._id || user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
        res.json({
            success: true,
            message: 'Login successful.',
            token,
            user: sanitizeUser(user)
        });
    } catch (err) {
        console.error('Login error:', err);
        res.status(500).json({ success: false, error: 'Server error during login.' });
    }
});

// -------------------------------------------------------------
// 3. MANDI PRICES & RECORDS
// -------------------------------------------------------------
router.get('/mandi-prices', async (req, res) => {
    try {
        const { state, crop, category, mandiType, sort, search, limit = 100 } = req.query;

        let records = [];
        if (isConnected()) {
            const query = {};
            if (state && state !== 'ALL') query.state = state;
            if (crop && crop !== 'ALL') query.crop = new RegExp(`^${crop}$`, 'i');
            if (category && category !== 'ALL') query.category = category.toLowerCase();
            if (mandiType && mandiType !== 'ALL') query.mandiType = mandiType;
            if (search) {
                query.$or = [
                    { crop: new RegExp(search, 'i') },
                    { mandi: new RegExp(search, 'i') },
                    { district: new RegExp(search, 'i') },
                    { state: new RegExp(search, 'i') }
                ];
            }

            let mongoQuery = MandiRecord.find(query);

            if (sort === 'price-desc') mongoQuery = mongoQuery.sort({ modal: -1 });
            else if (sort === 'price-asc') mongoQuery = mongoQuery.sort({ modal: 1 });
            else if (sort === 'name-asc') mongoQuery = mongoQuery.sort({ crop: 1 });
            else mongoQuery = mongoQuery.sort({ modal: -1 });

            records = await mongoQuery.limit(parseInt(limit)).lean();
        } else {
            records = [...memStore.mandiRecords];
            if (state && state !== 'ALL') records = records.filter(r => r.state === state);
            if (crop && crop !== 'ALL') records = records.filter(r => r.crop.toLowerCase() === crop.toLowerCase());
            if (category && category !== 'ALL') records = records.filter(r => r.category === category.toLowerCase());
            if (mandiType && mandiType !== 'ALL') records = records.filter(r => r.mandiType === mandiType);
            if (search) {
                const s = search.toLowerCase();
                records = records.filter(r => 
                    r.crop.toLowerCase().includes(s) ||
                    r.mandi.toLowerCase().includes(s) ||
                    (r.district && r.district.toLowerCase().includes(s)) ||
                    r.state.toLowerCase().includes(s)
                );
            }

            if (sort === 'price-desc') records.sort((a, b) => b.modal - a.modal);
            else if (sort === 'price-asc') records.sort((a, b) => a.modal - b.modal);
            else if (sort === 'name-asc') records.sort((a, b) => a.crop.localeCompare(b.crop));
            else if (sort === 'traded-desc') records.sort((a, b) => parseInt(String(b.traded).replace(/[^0-9]/g, '') || 0) - parseInt(String(a.traded).replace(/[^0-9]/g, '') || 0));
        }

        res.json({
            success: true,
            total: records.length,
            source: isConnected() ? 'MongoDB' : 'Memory Cache',
            data: records
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

router.post('/mandi-prices', async (req, res) => {
    try {
        const item = req.body;
        if (!item.crop || !item.state || !item.mandi || !item.price) {
            return res.status(400).json({ success: false, error: 'Crop, state, mandi and price are required.' });
        }

        const priceNum = Number(item.price);
        const newRecord = {
            id: Date.now(),
            crop: item.crop,
            variety: item.variety || 'Desi / Local',
            category: item.category || 'crop',
            state: item.state,
            district: item.district || '',
            mandi: item.mandi,
            price: priceNum,
            min: item.min ? Number(item.min) : Math.round(priceNum * 0.92),
            max: item.max ? Number(item.max) : Math.round(priceNum * 1.08),
            modal: item.modal ? Number(item.modal) : priceNum,
            traded: item.traded || '500 Qtl',
            mandiType: item.mandiType || 'APMC Market Yard',
            lat: item.lat ? Number(item.lat) : 20.5937,
            lng: item.lng ? Number(item.lng) : 78.9629,
            updated: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
            msp: item.msp ? Number(item.msp) : null,
            shelfLife: item.shelfLife || '30 Days',
            volatility: item.volatility ? Number(item.volatility) : 10.0,
            isSample: false
        };

        if (isConnected()) {
            const saved = await MandiRecord.create(newRecord);
            res.status(201).json({ success: true, message: 'Record saved to MongoDB.', data: saved });
        } else {
            memStore.mandiRecords.unshift(newRecord);
            res.status(201).json({ success: true, message: 'Record saved to in-memory store.', data: newRecord });
        }
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// -------------------------------------------------------------
// 4. PRODUCT COMPARISON API
// -------------------------------------------------------------
router.get('/compare', async (req, res) => {
    try {
        const { cropA = 'Tomato', cropB = 'Potato', areaA = 'ALL', areaB = 'ALL' } = req.query;

        let allRecords = [];
        if (isConnected()) {
            allRecords = await MandiRecord.find().lean();
        } else {
            allRecords = memStore.mandiRecords;
        }

        const recordsA = areaA === 'ALL' ? allRecords : allRecords.filter(r => r.state === areaA);
        const recordsB = areaB === 'ALL' ? allRecords : allRecords.filter(r => r.state === areaB);

        const itemA = recordsA.find(r => r.crop.toLowerCase() === cropA.toLowerCase()) ||
                      allRecords.find(r => r.crop.toLowerCase() === cropA.toLowerCase());
        const itemB = recordsB.find(r => r.crop.toLowerCase() === cropB.toLowerCase()) ||
                      allRecords.find(r => r.crop.toLowerCase() === cropB.toLowerCase());

        if (!itemA || !itemB) {
            return res.status(404).json({
                success: false,
                error: `Could not find price data for ${!itemA ? cropA : cropB}.`
            });
        }

        const priceDiff = itemA.modal - itemB.modal;
        const priceDiffPct = itemB.modal > 0 ? Number(((priceDiff / itemB.modal) * 100).toFixed(1)) : 0;

        res.json({
            success: true,
            productA: itemA,
            productB: itemB,
            comparison: {
                modalDiff: priceDiff,
                modalDiffPct: priceDiffPct,
                higherPriced: priceDiff >= 0 ? itemA.crop : itemB.crop,
                spreadA: itemA.max - itemA.min,
                spreadB: itemB.max - itemB.min,
                arbitrageOpportunity: Math.abs(priceDiff) > 300,
                recommendedTransportCap: Math.round(Math.abs(priceDiff) * 0.4)
            }
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// -------------------------------------------------------------
// 5. PRICE & MARKET TREND ANALYSIS API
// -------------------------------------------------------------
router.get('/trends', async (req, res) => {
    try {
        const { crop = 'Wheat', mode = 'crop', timeframe = '3M' } = req.query;

        let allRecords = [];
        if (isConnected()) {
            allRecords = await MandiRecord.find().lean();
        } else {
            allRecords = memStore.mandiRecords;
        }

        // Group by crop to rank opportunities
        const cropGroups = {};
        allRecords.forEach(item => {
            if (!cropGroups[item.crop]) {
                cropGroups[item.crop] = {
                    crop: item.crop,
                    prices: [],
                    spreads: [],
                    volatilities: [],
                    mandis: []
                };
            }
            cropGroups[item.crop].prices.push(item.modal || item.price);
            cropGroups[item.crop].spreads.push(Math.max(0, (item.max || item.price) - (item.min || item.price)));
            cropGroups[item.crop].volatilities.push(item.volatility || 12);
            cropGroups[item.crop].mandis.push(`${item.mandi} (${item.state})`);
        });

        const cropRankings = Object.values(cropGroups).map(g => {
            const avgPrice = Math.round(g.prices.reduce((a, b) => a + b, 0) / g.prices.length);
            const avgSpread = Math.round(g.spreads.reduce((a, b) => a + b, 0) / g.spreads.length);
            const avgVol = Number((g.volatilities.reduce((a, b) => a + b, 0) / g.volatilities.length).toFixed(1));
            const farmerScore = Math.min(100, Math.round(50 + (avgPrice > 2500 ? 25 : 10) - avgVol * 0.8));
            const traderScore = Math.min(100, Math.round(avgSpread * 0.15 + (avgVol > 15 ? 30 : 15)));

            return {
                crop: g.crop,
                avgPrice,
                avgSpread,
                avgVolatility: avgVol,
                mandiCount: g.mandis.length,
                farmerScore,
                traderScore
            };
        });

        res.json({
            success: true,
            timeframe,
            cropRankings: cropRankings.sort((a, b) => b.traderScore - a.traderScore)
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// -------------------------------------------------------------
// 6. FAVORITES API
// -------------------------------------------------------------
router.get('/favorites', async (req, res) => {
    try {
        const userEmail = req.query.email || 'farmer@agriprice.org';
        if (isConnected()) {
            const favorites = await Favorite.find({ userEmail }).lean();
            res.json({ success: true, data: favorites });
        } else {
            const favorites = memStore.favorites.filter(f => f.userEmail === userEmail);
            res.json({ success: true, data: favorites });
        }
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

router.post('/favorites', async (req, res) => {
    try {
        const { userEmail = 'farmer@agriprice.org', crop, category, mandi, state, price, modal, min, max, traded } = req.body;
        if (!crop) return res.status(400).json({ success: false, error: 'Crop name is required.' });

        const newFav = {
            id: Date.now(),
            userEmail,
            crop,
            category: category || 'crop',
            mandi: mandi || 'Local Mandi',
            state: state || 'All India',
            price: price || 2000,
            modal: modal || price || 2000,
            min: min || (price ? price * 0.9 : 1800),
            max: max || (price ? price * 1.1 : 2200),
            traded: traded || '1,000 Qtl',
            change: '+1.5%'
        };

        if (isConnected()) {
            const saved = await Favorite.create(newFav);
            res.status(201).json({ success: true, data: saved });
        } else {
            memStore.favorites.push(newFav);
            res.status(201).json({ success: true, data: newFav });
        }
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// -------------------------------------------------------------
// 7. CLOUDFLARE TURNSTILE (PRESERVED FOR COMPATIBILITY)
// -------------------------------------------------------------
router.get('/config', (req, res) => {
    const siteKey = process.env.TURNSTILE_SITE_KEY || '';
    const enabled = Boolean(siteKey && process.env.TURNSTILE_SECRET_KEY);
    res.json({ enabled, siteKey: enabled ? siteKey : '' });
});

router.post('/verify-turnstile', async (req, res) => {
    const secretKey = process.env.TURNSTILE_SECRET_KEY;
    if (!process.env.TURNSTILE_SITE_KEY || !secretKey) {
        return res.status(503).json({ success: false, error: 'Turnstile is not configured.' });
    }

    const { token, action } = req.body;
    if (typeof token !== 'string' || !token || action !== 'register') {
        return res.status(400).json({ success: false, error: 'A valid Turnstile token and action are required.' });
    }

    try {
        const verificationResponse = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ secret: secretKey, response: token })
        });
        if (!verificationResponse.ok) {
            return res.status(502).json({ success: false, error: 'Cloudflare verification is unavailable.' });
        }

        const verification = await verificationResponse.json();
        const isCloudflareTestKey = verification.metadata?.result_with_testing_key === true;
        const requestOrigin = req.headers.origin || `http://${req.headers.host}`;
        const requestHostname = new URL(requestOrigin).hostname;
        const isLocalDevelopment = process.env.NODE_ENV !== 'production'
            && ['localhost', '127.0.0.1', '::1'].includes(requestHostname);
        const actionMatches = verification.action === action || (isCloudflareTestKey && isLocalDevelopment);
        const success = verification.success === true && actionMatches;
        return res.status(success ? 200 : 400).json({ success });
    } catch (error) {
        return res.status(502).json({ success: false, error: 'Cloudflare verification service unreachable.' });
    }
});

module.exports = router;
